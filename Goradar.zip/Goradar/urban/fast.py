with open('nr.geojson') as f:
    s = load(f)
    for i in s:
        for j in range(len(s[i]["features"])):
            s[i][j]["properties"]["problems"] = []
dump(s, open('nr1.json', 'w+'), ensure_ascii=False, indent=4, sort_keys=True)
