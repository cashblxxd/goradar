from django.contrib import admin
from .models import Entity, Attribute, Object, AttributeTittle


class AttributeInLine(admin.StackedInline):
	model = Attribute
	extra = 1

class ObjectInLine(admin.StackedInline):
	model = Object
	extra = 1

class EnityAdmin(admin.ModelAdmin):
	fields=['enity_text', 'enity_author']
	inlines = [AttributeInLine, ObjectInLine]

class AttributeTittleInLine(admin.StackedInline):
	model = AttributeTittle
	extra = 1

class ObjectAdmin(admin.ModelAdmin):
	inlines = [AttributeTittleInLine]

admin.site.register(Entity, EnityAdmin)
admin.site.register(Attribute)
admin.site.register(Object, ObjectAdmin)
admin.site.register(AttributeTittle)
