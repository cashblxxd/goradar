from django.urls import path, include
from django.conf.urls import url
from . import views

urlpatterns = [
    path('', views.start, name='start'),
    path('myenities/', views.enities, name='enities'),
    url(r'get/(?P<id>\d+)/', views.enity),
    url(r'addattribute/(?P<id>\d+)/', views.addattribute),
    url(r'startresearch/(?P<id>\d+)/', views.createobject),
    url(r'myobjects/(?P<id>\d+)/', views.objects),
    url(r'(?P<enity_id>\d+)/qwer/(?P<object_id>\d+)/', views.object),
    url(r'addattribute/fd/(?P<object_id>\d+)/(?P<enity_id>\d+)', views.addattributetittle),
]
