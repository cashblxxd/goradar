from django import forms
from .models import Entity, Attribute, Object, AttributeTittle

class EntityForm(forms.ModelForm):
	enity_text=forms.CharField(label='Сущность')
	class Meta():
		model = Entity
		fields = ('enity_text',)

class AttributeForm(forms.ModelForm):
	attribute_text=forms.CharField(label='Напишите атрибут')
	class Meta():
		model = Attribute
		fields = ('attribute_text',)

class ObjectForm(forms.ModelForm):
	object_tittle = forms.CharField(label='Геопривязка(адрес, координаты и тд)')
	class Meta():
		model = Object
		fields = ('object_tittle',)		

class AttributeTittleForm(forms.ModelForm):
	attribute_tittle_text = forms.CharField(label='')
	class Meta():
		model = AttributeTittle
		fields = ('attribute_tittle_text',)	
