from django.db import models
from django.conf import settings
from django.contrib import auth 

class Entity(models.Model):
	class Meta():
		db_table = "enity"
	enity_author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
	enity_text = models.CharField(max_length=100)

class Attribute(models.Model):
	class Meta():
		db_table = "attribute"
	attribute_text = models.CharField(max_length=100)
	attribute_entity = models.ForeignKey(Entity, on_delete=models.PROTECT)

class Object(models.Model):
	class Meta():
		db_table = 'object'
	object_tittle = models.CharField(max_length=100)
	object_entity = models.ForeignKey(Entity, on_delete=models.PROTECT)

class AttributeTittle(models.Model):
	class Meta():
		db_table= "attribute_tittle"
	attribute_tittle_text = models.CharField(max_length=100)
	object_tittle_object = models.ForeignKey(Object, on_delete=models.PROTECT)