from django.shortcuts import render, redirect
from .forms import EntityForm, AttributeForm, ObjectForm, AttributeTittleForm
from django.contrib import auth 
from django.template.context_processors import csrf
from .models import Entity, Attribute, Object, AttributeTittle

def start(request):
	if request.method == 'POST':
		form = EntityForm(request.POST)
		if form.is_valid():
			post = form.save(commit=False)
			post.enity_author = request.user
			post.save()
			return render(request, 'research/research_done.html', {'post': post})
	else:
		form = EntityForm()
	return render(request, 'research/research.html', {'form': form, 'username': auth.get_user(request).username})

def enities(request):
	return render(request, 'research/enities.html', {'enities': Entity.objects.filter(enity_author = request.user),'username': auth.get_user(request).username })

def enity(request, id = 1):
	attribute_form = AttributeForm
	args = {}
	args.update(csrf(request))
	args['enity'] = Entity.objects.get(id = id)
	args['attributes'] = Attribute.objects.filter(attribute_entity_id= id)
	args['username'] = auth.get_user(request).username
	args['form'] = attribute_form
	return render(request, 'research/enity.html', args)

def addattribute(request, id):
	if request.method == 'POST':
		form = AttributeForm(request.POST)
		if form.is_valid():
			comment = form.save(commit=False)
			comment.attribute_entity = Entity.objects.get(id=id)
			form.save()
	else: 
	    form = AttributeForm()
	    c.update(locals())
	    return HttpResponseRedirect(request.path_info)
	return redirect('/research/get/%s/'%id)

def createobject(request, id):
	if request.method == 'POST':
		form = ObjectForm(request.POST)
		if form.is_valid():
			post = form.save(commit=False)
			post.object_entity = Entity.objects.get(id = id)
			form.save()
	args = {}
	args.update(csrf(request))
	args['enity'] = Entity.objects.get(id = id)
	args['username'] = auth.get_user(request).username
	args['form'] = ObjectForm()
	return render(request, 'research/startresearch.html', args)

def objects(request, id):
	args = {}
	args.update(csrf(request))
	args['enity'] = Entity.objects.get(id = id)
	args['username'] = auth.get_user(request).username
	args['objects'] = Object.objects.filter(object_entity = id)
	return render(request, 'research/objects.html', args)

def object(request, enity_id, object_id):
	form = AttributeTittleForm
	args={}
	args.update(csrf(request))
	args['enity'] = Entity.objects.get(id = enity_id)
	args['attributes'] = Attribute.objects.filter(attribute_entity_id= enity_id)
	args['username'] = auth.get_user(request).username
	args['form'] = form
	args['object'] = Object.objects.get(id = object_id)
	args['attributes_tittle'] = AttributeTittle.objects.filter(object_tittle_object = object_id)
	return render(request, 'research/object.html', args)

def addattributetittle(request, object_id, enity_id):
	if request.method == 'POST':
		form = AttributeTittleForm(request.POST)
		if form.is_valid():
			comment = form.save(commit=False)
			comment.object_tittle_object = Object.objects.get(id=object_id)
			form.save()
	else: 
	    form = AttributeTittleForm()
	    c.update(locals())
	    return HttpResponseRedirect(request.path_info)
	return redirect('/research/%s/qwer/%s/'%(enity_id, object_id))



