from django.contrib import admin
from .models import Report

class ReportAdmin(admin.ModelAdmin):
	fields = ['report_author', 'report_type','report_subtype','report_problem', 'report_published_date', 'report_photo', 'report_description', 'report_object_id', 'report_end']

admin.site.register(Report,ReportAdmin)