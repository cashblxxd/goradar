from django.apps import AppConfig


class LoginsysConfig(AppConfig):
    name = 'loginsys'
