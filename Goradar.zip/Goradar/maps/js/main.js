mapboxgl.accessToken = 'pk.eyJ1IjoiY2hyb290IiwiYSI6ImNqeHZzcWtjNjA3dTIzZ2s5OG5sb25xOWwifQ.MIcpNykvUL0-KI-wVzh0XQ';
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/dark-v10',
    zoom: 11,
    center: [39.9239, 43.429]
});

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("text/plain");
    rawFile.open("GET", file, true);
    rawFile.setRequestHeader("Access-Control-Allow-Origin", "*");
    rawFile.setRequestHeader("Access-Control-Allow-Origin", "GET");
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

var toggleableLayerIds = ["bicycle_road_layer", "boulevard_layer", "building_layer", "commercial_layer", "companies_full_layer", "crossing_layer", "footway_layer", "lawn_layer", "maf_layer", "mixed_layer", "park_layer", "recycle_map_layer", "stop_layer", "street_lamp_layer", "subway_station_layer", "traffic_signal_layer", "vehicle_road_layer", "water_layer", "yard_layer"];

var pics = {"bicycle_road": "rgba(136,17,15,1)",
 "boulevard": "rgba(117,158,252,1)",
 "building": "rgba(156,21,101,1)",
 "commercial": "rgba(101,234,4,1)",
 "companies_full": "rgba(24,199,188,1)",
 "crossing": "rgba(26,67,39,1)",
 "footway": "rgba(55,182,121,1)",
 "lawn": "rgba(34,47,208,1)",
 "maf": "rgba(51,190,102,1)",
 "park": "rgba(203,82,225,1)",
 "recycle_map": "rgba(182,12,156,1)",
 "stop": "rgba(111,178,213,1)",
 "street_lamp": "rgba(16,141,123,1)",
 "subway_station": "rgba(180,119,112,1)",
 "traffic_signal": "rgba(76,251,187,1)",
 "vehicle_road": "rgba(227,222,151,1)",
 "water": "rgba(225,154,5,1)",
 "yard": "rgba(136,115,65,1)",
"mixed": "rgba(56,226,189,1)"}

 var rev = {'id': 'id',
 'Автодорога': 'vehicle_road',
 'Автодороги': 'vehicle_road_layer',
 'Адрес': 'address',
 'Банкомат': 'atm',
 'Бульвар': 'boulevard',
 'Велодорожка': 'bicycle_road',
 'Велодорожки': 'bicycle_road_layer',
 'Вид': 'amenity',
 'Водные объекты': 'water_layer',
 'Водный объект': 'water',
 'Газоны': 'lawn_layer',
 'Год постройки': 'built_year',
 'Городские здания': 'building_layer',
 'Двор': 'yard',
 'Дворы': 'yard_layer',
 'Доступ в Интернет': 'internet_access',
 'Досуг': 'leisure',
 'Заглавие': 'title',
 'Здания общего назначения': 'mixed_layer',
 'ИНН': 'inn',
 'Имя директора': 'name_employee',
 'Кол-во жителей': 'inhabitants_count',
 'Кол-во этажей': 'building:levels',
 'Коммерческие здания': 'commercial_layer',
 'Лужайка': 'lawn',
 'МАФ': 'maf',
 'Малые архитектурные формы': 'maf_layer',
 'Марка': 'brand',
 'Места переработки': 'recycle_map_layer',
 'Местонахождение': 'location',
 'Мост': 'bridge',
 'Название': 'name',
 'Находится в критическом состоянии': 'is_alarm',
 'ОГРН': 'orn',
 'Обслуживающая пожарная организация': 'fire_operator',
 'Оператор': 'operator',
 'Описание': 'description',
 'Парк': 'park',
 'Парки': 'park_layer',
 'Перекрёстки': 'crossing_layer',
 'Перекрёсток': 'crossing',
 'Пешеходная дорожка': 'footway',
 'Пешеходные дорожки': 'footway_layer',
 'Сайт': 'site',
 'Сбор утилизируемых отходов': 'recycle_map',
 'Светофоры': 'traffic_signal_layer',
 'Сигнал светофора': 'traffic_signal',
 'Скамейка': 'bench',
 'Сквер и бульвар': 'boulevard_layer',
 'Смешанный': 'mixed',
 'Сокр. имя': 'name_short',
 'Станции метро': 'subway_station_layer',
 'Станция метро': 'subway_station',
 'Стоп': 'stop',
 'Стоянки': 'stop_layer',
 'Строительство': 'building',
 'Тактильная разметка': 'tactile_paving',
 'Телефон': 'phone',
 'Тип': 'type',
 'Уличный фонарь': 'street_lamp',
 'Управляющие компании': 'companies_full_layer',
 'Упраляющая компания': 'companies_full',
 'Фонари': 'street_lamp_layer',
 'Шоссе': 'highway',
 'Эл. адрес': 'email'
}

var links = {
    "bicycle_road": "roadnetwork/",
    "boulevard": "greenzone/",
    "building": "buildings/",
    "commercial": "buildings/",
    "companies_full": "",
    "crossing": "transition/",
    "footway": "roadnetwork/",
    "lawn": "greenzone/",
    "maf": "",
    "park": "greenzone/",
    "recycle_map": "",
    "stop": "stoppingpoint/",
    "street_lamp": "roadnetwork/",
    "subway_station": "stoppingpoint/",
    "traffic_signal": "roadnetwork/",
    "vehicle_road": "roadnetwork/",
    "water": "waterbody/",
    "yard": "yard/",
    "mixed": "buildings/"
}

var translations = {
    "actual_address": "Адрес",
    "address": "Адрес",
    "amenity": "Вид",
    "atm": "Банкомат",
    "bench": "Скамейка",
    "bicycle_road": "Велодорожка",
    "boulevard": "Бульвар",
    "brand": "Марка",
    "bridge": "Мост",
    "building": "Строительство",
    "building:levels": "Кол-во этажей",
    "built_year": "Год постройки",
    "commercial": "Коммерческие здания",
    "companies_full": "Упраляющая компания",
    "crossing": "Перекрёсток",
    "description": "Описание",
    "email": "Эл. адрес",
    "fire_operator": "Обслуживающая пожарная организация",
    "footway": "Пешеходная дорожка",
    "highway": "Шоссе",
    "id": "id",
    "inhabitants_count": "Кол-во жителей",
    "inn": "ИНН",
    "internet_access": "Доступ в Интернет",
    "is_alarm": "Находится в критическом состоянии",
    "lawn": "Лужайка",
    "leisure": "Досуг",
    "location": "Местонахождение",
    "maf": "МАФ",
    "mixed": "Смешанный",
    "name": "Название",
    "name_employee": "Имя директора",
    "name_short": "Сокр. имя",
    "operator": "Оператор",
    "orn": "ОГРН",
    "park": "Парк",
    "phone": "Телефон",
    "recycle_map": "Сбор утилизируемых отходов",
    "site": "Сайт",
    "stop": "Стоп",
    "street_lamp": "Уличный фонарь",
    "subway_station": "Станция метро",
    "tactile_paving": "Тактильная разметка",
    "title": "Заглавие",
    "traffic_signal": "Сигнал светофора",
    "type": "Тип",
    "vehicle_road": "Автодорога",
    "water": "Водный объект",
    "yard": "Двор",
    "bicycle_road_layer": "Велодорожки",
    "boulevard_layer": "Сквер и бульвар",
    "building_layer": "Городские здания",
    "commercial_layer": "Коммерческие здания",
    "companies_full_layer": "Управляющие компании",
    "crossing_layer": "Перекрёстки",
    "footway_layer": "Пешеходные дорожки",
    "lawn_layer": "Газоны",
    "maf_layer": "Малые архитектурные формы",
    "mixed_layer": "Здания общего назначения",
    "park_layer": "Парки",
    "recycle_map_layer": "Места переработки",
    "stop_layer": "Стоянки",
    "street_lamp_layer": "Фонари",
    "subway_station_layer": "Станции метро",
    "traffic_signal_layer": "Светофоры",
    "vehicle_road_layer": "Автодороги",
    "water_layer": "Водные объекты",
    "yard_layer": "Дворы"
}


map.on('load', function () {

    readTextFile("/static/nr.json", function(text){
        data = JSON.parse(text);
        for (var d in data) {

          map.addSource(d + "_source", {
              "type": "geojson",
              "data": data[d]
          });

          map.addLayer({
              'id': d + "_layer",
              'type': 'circle',
              'source': d + "_source",
              'layout': {
                  'visibility': 'visible',
              },
              'paint': {
                'circle-radius': 8,
                'circle-color': pics[d]
              }
          });

        }

        for (var d in data) {
          var popup = new mapboxgl.Popup({
              closeButton: true,
              closeOnClick: false
          });
          map.on('click', d + '_layer', function(e) {
              if (e.features[0].geometry.type == "Point") {
                  var coordinates = e.features[0].geometry.coordinates.slice();
                  map.getCanvas().style.cursor = 'pointer';

                  var table = document.createElement("table");
                  var tr = table.insertRow(-1);
                  for (var key in e.features[0].properties) {
                      if (key == 'email' || key == 'inn' || key == 'name_employee' || key == 'orn' || key == 'phone' || key == 'site' || key == 'problems') continue;
                      var tr = table.insertRow(-1);
                      var tabCell = tr.insertCell(-1);
                      tabCell.innerHTML = translations[key];
                      var tabCell2 = tr.insertCell(-1);
                      tabCell2.innerHTML = e.features[0].properties[key];
                  }

                  var table1 = document.createElement("table");
                  var tr = table1.insertRow(-1);
                  var tabCell = tr.insertCell(-1);
                  tabCell.innerHTML = e.features[0].properties.problems;

                  while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
                    coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
                  }

                  popup.setLngLat(coordinates)
                  .setHTML('<table>' + table.innerHTML + '</table><br>Проблемы<br><table>' + table1.innerHTML + '</table><a target="_blank" style="target-new: tab;" href="/report/">Сообщить о проблеме</a>')
                  .addTo(map);

              } else {
                for(var c in e.features[0].geometry.coordinates) {
                    var coordinates = e.features[0].geometry.coordinates[c].slice();
                    map.getCanvas().style.cursor = 'pointer';

                    var table = document.createElement("table");
                    var tr = table.insertRow(-1);
                    for (var key in e.features[0].properties) {
                        if (key == 'email' || key == 'inn' || key == 'name_employee' || key == 'orn' || key == 'phone' || key == 'site' || key == 'problems') continue;
                        var tr = table.insertRow(-1);
                        var tabCell = tr.insertCell(-1);
                        tabCell.innerHTML = translations[key];
                        var tabCell2 = tr.insertCell(-1);
                        tabCell2.innerHTML = e.features[0].properties[key];
                    }

                    var table1 = document.createElement("table");
                    var tr = table1.insertRow(-1);
                    var tabCell = tr.insertCell(-1);
                    tabCell.innerHTML = e.features[0].properties.problems;

                    while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
                      coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
                    }

                    popup.setLngLat(coordinates)
                    .setHTML('<table>' + table.innerHTML + '</table><br>Проблемы<br><table>' + table1.innerHTML + '</table><a target="_blank" style="target-new: tab;" href="/report/">Сообщить о проблеме</a>')
                    .addTo(map);
                }

              }
          });
        }

    });

    var layers = map.getStyle().layers;

    var labelLayerId;
    for (var i = 0; i < layers.length; i++) {
        if (layers[i].type === 'symbol' && layers[i].layout['text-field']) {
            labelLayerId = layers[i].id;
            break;
        }
    }

    map.addLayer({
        'id': '3d-buildings',
        'source': 'composite',
        'source-layer': 'building',
        'filter': ['==', 'extrude', 'true'],
        'type': 'fill-extrusion',
        'minzoom': 15,
        'paint': {
            'fill-extrusion-color': '#aaa',

            // use an 'interpolate' expression to add a smooth transition effect to the
            // buildings as the user zooms in
            'fill-extrusion-height': [
                "interpolate", ["linear"], ["zoom"],
                15, 0,
                15.05, ["get", "height"]
            ],
            'fill-extrusion-base': [
                "interpolate", ["linear"], ["zoom"],
                15, 0,
                15.05, ["get", "min_height"]
            ],
            'fill-extrusion-opacity': .6
        }
    }, labelLayerId);
});

var layers = document.getElementById('menu');

for (var i = 0; i < toggleableLayerIds.length; i++) {
    var id = toggleableLayerIds[i];

    var link = document.createElement('a');
    link.href = '#';
    link.className = 'active';
    link.textContent = translations[id];

    link.onclick = function (e) {
        var clickedLayer = rev[this.textContent];
        e.preventDefault();
        e.stopPropagation();

        var visibility = map.getLayoutProperty(clickedLayer, 'visibility');

        if (visibility === 'visible') {
            map.setLayoutProperty(clickedLayer, 'visibility', 'none');
            this.className = '';
        } else {
            this.className = 'active';
            map.setLayoutProperty(clickedLayer, 'visibility', 'visible');
        }
    };

    layers.appendChild(link);
}
