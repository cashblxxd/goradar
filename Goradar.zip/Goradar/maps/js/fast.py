from json import load, dump, loads

with open('nr.json') as f:
    s = load(f)
    for i in s:
        for j in range(len(s[i]["features"])):
            s[i]["features"][j]["properties"]["problems"] = []
dump(s, open('nr1.json', 'w+'), ensure_ascii=False, indent=4, sort_keys=True)

