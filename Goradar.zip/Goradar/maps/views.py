from django.shortcuts import render
from django.contrib import auth

def maps(request):
	return render(request, 'maps/new.html')
