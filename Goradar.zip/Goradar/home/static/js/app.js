$(document).foundation()
*{
	